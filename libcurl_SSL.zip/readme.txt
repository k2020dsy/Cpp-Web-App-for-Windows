说明：
对libcurl版本的封装，支持openssl
libcurl版本：curl-7.62.0
openssl版本：1.0.2 

使用动态库需要同时将附带的两个库添加到EXE文件夹下。
如果使用动态库，要想使开发的程序到处可执行，需要将vs的执行库也打包到EXE文件夹下，一般为msvcrxxx,msvcpxxx,xxx为你所使用的VS版本代码，例如VS2010为100.